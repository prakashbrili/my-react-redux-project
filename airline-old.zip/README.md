This is a simple boilerplate for React Web Apps...
Developed by changing some features from this -  https://github.com/prakashbrili/my-react-redux-project.git


```
npm install

npm start

color code selection : https://color.adobe.com/explore/
Design inspiration : Dribbble
fonts : goolge fonts
datasource : airline/src/utility/dataSource.js



/**
 * Created by prakash.shivanna on 12/11/17.
 */

import React from 'react';
import { Link } from 'react-router';

export default (props) => {
    return (
        <header className="headerWrap App-content clearfix">
            <div className="brandContainer">
                <Link to="/" href="#" className="brand">
                    <span>Airline</span>
                </Link>
            </div>
        </header>
    );
}

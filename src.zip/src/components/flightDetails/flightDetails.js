/**
 * Created by prakash.shivanna on 13/11/17.
 */

import React from "react";
import "./flightDetail.scss";
import ClassNames from "classnames";

const FlightDetails = ({data, idUpdate, classNames}) => {
    const classes = ClassNames("flights flights__detail", classNames);
    const depDate = new Date(data.departDate);
    const depDateString = depDate.toLocaleDateString();
    const arrDate = new Date(data.arriveDate);
    const arrDateString = arrDate.toLocaleDateString();

    const retDepDate = new Date(data.returnTrip.departDate);
    const retDepDateString = retDepDate.toLocaleDateString();

    const retArrDate = new Date(data.returnTrip.arriveDate);
    const retArrDateString = retArrDate.toLocaleDateString();

    return (

        <div className={classes}>
            <div className="flights__price">
                <h2>Rs: {data.price}</h2>
                <button className="button--booking" onClick={ () => idUpdate(data) }>Submit</button>
            </div>
            <div className="flights__detail">
                <div className="flights--departure">
                    <h4>{data.number}</h4>
                    <h2>{data.origin} > {data.destination} </h2>
                    <h4>Depart : {depDateString}</h4>
                    <h4>Arrival : {arrDateString}</h4>
                </div>
                <div className="flights--arrival">
                    <h4>{data.returnTrip.number}</h4>

                    <h2>{data.returnTrip.origin} > {data.returnTrip.destination} </h2>
                    <h4>Depart : {retDepDateString}</h4>
                    <h4>Arrival : {retArrDateString}</h4>

                </div>
                <div className="flights--image">
                    <img alt={data.airline}
                         src={require(`../../static/images/flights/${data.image}`)}/>
                </div>
            </div>
        </div>
    );
};


export default FlightDetails;

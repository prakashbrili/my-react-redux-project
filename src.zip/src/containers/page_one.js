import React, { Component } from 'react';

class PageOne extends Component {
  render() {
    return (
      <h2>Page One</h2>
    );
  }
}

export default PageOne;
